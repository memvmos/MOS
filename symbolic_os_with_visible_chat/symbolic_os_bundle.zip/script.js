
document.querySelector('.tile.because').addEventListener('click', () => {
  alert("∵: This is true *because* 2 and 3 joined to form 5.");
});

document.getElementById('showCodeBtn').addEventListener('click', () => {
  const codeBlock = document.getElementById('codeBlock');
  if (codeBlock.style.display === 'none') {
    fetch('index.html')
      .then(response => response.text())
      .then(text => {
        codeBlock.textContent = text;
        codeBlock.style.display = 'block';
      });
  } else {
    codeBlock.style.display = 'none';
  }
});
